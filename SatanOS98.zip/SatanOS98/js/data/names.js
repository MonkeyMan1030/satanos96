// js/data/names.js
window.SATANOS_NAMES = {
  first: ["Alex","Jordan","Taylor","Casey","Morgan","Riley","Jamie","Avery","Drew","Sam","Quinn","Parker","Skyler","Cameron","Reese","Rowan","Kendall","Hayden","Charlie","Devon"],
  last:  ["Graves","Holloway","Blackwood","Roth","Marrow","Crowley","Voss","Ashford","Grimm","Gallow","Thorne","Briar","Cinder","Wolfe","Harker","Knox","Sable","Vale","Mordane","Wraith"]
};
